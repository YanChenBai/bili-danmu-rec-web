<template>
    <RouterView></RouterView>
</template>
<script setup lang="ts">
defineOptions({ name: "RoomIndex" });
</script>

<style scoped lang="scss"></style>