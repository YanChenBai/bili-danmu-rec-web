<template>
    <RouterView></RouterView>
</template>
<script setup lang="ts">
defineOptions({ name: "RoomDanmuIndex" });
</script>

<style scoped lang="scss"></style>