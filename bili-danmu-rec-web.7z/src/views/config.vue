<template>
    配置
    <RouterView></RouterView>
</template>
<script setup lang="ts">
defineOptions({ name: "Config" });
</script>

<style scoped lang="scss"></style>