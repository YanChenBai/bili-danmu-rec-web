<template>
    统计
    <RouterView></RouterView>
</template>
<script setup lang="ts">
defineOptions({ name: "statistics" });
</script>

<style scoped lang="scss"></style>