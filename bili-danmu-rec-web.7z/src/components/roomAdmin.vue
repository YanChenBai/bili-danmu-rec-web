<template>
    <div class="room-admin">房管</div>
</template>
<script setup lang="ts">
defineOptions({ name: "RoomAdmin" });
</script>
<style scoped lang="scss">
.room-admin {
    height: 20px;
    padding: 0 4px;
    border-radius: 2px;
    background: rgb(255, 136, 0);
}
</style>